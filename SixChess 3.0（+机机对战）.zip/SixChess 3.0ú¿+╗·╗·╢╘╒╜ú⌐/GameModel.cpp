#include "GameModel.h"

GameModel::GameModel()
{
   mode=PVP;
}
