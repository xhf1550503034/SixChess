#ifndef AIPK_H
#define AIPK_H
#include <QMainWindow>
#include"ChessBoard.h"
#include"ChessNode.h"
#include"Algorithm.h"
#include<QLabel>
#include"ChessAI.h"
#include<QTimer>
//#include"GameModel.h"
class aiPK : public QMainWindow
{
    Q_OBJECT
    int boardRow;
    int boardCol;
public:
    explicit aiPK(QWidget *parent = nullptr);
    void paintEvent(QPaintEvent *);
    void mouseMoveEvent(QMouseEvent *);
    void mouseReleaseEvent(QMouseEvent *);
      QLabel * lb_white_position=new QLabel(this);

      QLabel * lb_black_position=new QLabel(this);
     Algorithm algorithm;

     ChessAI ai;
     //void updateGameBoard(int board[23][23]);
     int aiRow;
     int aiCol;
    bool isblack;
    void actionByAI(int&aiRow, int&aiCol);
public slots:
    void oneChessByAIW();
    void oneChessByAIB();
    void mySlot2();

signals:
    void ComeBack();
};

#endif // AIPK_H
