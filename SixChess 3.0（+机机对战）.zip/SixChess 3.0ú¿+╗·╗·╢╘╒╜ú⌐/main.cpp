#include "mainwindow.h"
#include <QApplication>
#include"Server.h"
#include"Client.h"
#include"Welcome.h"
#include<QDebug>

int main(int argc, char *argv[])
{
    QApplication a(argc, argv);

    Welcome w1;
    w1.show();


    return a.exec();
}
