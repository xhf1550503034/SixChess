#ifndef CHESSNODE_H
#define CHESSNODE_H

//棋子类，包含位置、哪方棋手等属性，以及构造函数，对外接口函数
class ChessNode
{
private:
       int location_x;
       int location_y;
       int playerid;//判断棋手 -1为无人下，0为持黑棋者，1为持白棋者
public:
    ChessNode();
    void SetX(int x);
    void setY(int y);
    void setId(int id);
    int getX();
    int getY();
    int getId();
    void setChessNode(int x, int y,int id);
};

#endif // CHESSNODE_H
