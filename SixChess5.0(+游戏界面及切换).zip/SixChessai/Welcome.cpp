#include "Welcome.h"
#include "ui_Welcome.h"
#include<QPainter>
#include<QPixmap>
#include"mainwindow.h"
#include"Server.h"
#include"Client.h"
#include<QDebug>
#include"GameModel.h"
//#include"PVAI.h"
Welcome::Welcome(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::Welcome)
{
    ui->setupUi(this);
    setFixedSize(1400,800);
    setWindowTitle("六子棋游戏");
    ui->pushButton->setFixedSize(150,50);
    ui->pushButton->move(300,650);
    ui->pushButton_2->setFixedSize(150,50);
    ui->pushButton_2->move(800,650);
    connect(&m,&MainWindow::ComeBack,this,[=](){
        this->show();
        m.hide();

    });
    connect(&a1,&aiVp::ComeBack,this,[=](){
        this->show();
        a1.hide();

    });
    connect(&a,&aiPK::ComeBack,this,[=](){
        this->show();
        a.hide();

    });
    connect(&c,&Client::ComeBack,this,[=](){
        this->show();
        c.hide();
        s.hide();

    });
    connect(&s,&Server::ComeBack,this,[=](){
        this->show();
        c.hide();
        s.hide();

    });

}

Welcome::~Welcome()
{
    delete ui;
}
void Welcome::paintEvent(QPaintEvent *){
    QPainter painter(this);
    painter.drawPixmap(0,0,width(),height(),QPixmap(":/img/游戏界面.png"));
}


void Welcome::on_pushButton_2_clicked()
{
     this->hide();
}

void Welcome::on_action1_triggered()
{
    g.mode=PVP;
}

void Welcome::on_action2_triggered()
{
  g.mode=PVAI;
}

void Welcome::on_action3_triggered()
{
    g.mode=AIVAI;
}

void Welcome::on_action4_triggered()
{
   g.mode=NETWORK;
}


void Welcome::on_pushButton_clicked()

{if(g.mode==PVP){

        m.show();

    }
else if(g.mode==PVAI){
       a1.show();
    }
    else if(g.mode==AIVAI){
        a.show();
    }
else if(g.mode==NETWORK){
        //qDebug()<<"网络对战";
        s.show();
        c.show();


    }

    this->hide();


}

