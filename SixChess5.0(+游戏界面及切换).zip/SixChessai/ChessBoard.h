#ifndef CHESSBOARD_H
#define CHESSBOARD_H
#include"ChessNode.h"
#include<QStack>
#include<stack>

class ChessBoard
{

    public:
    int size;
    ChessNode ** chessNodes;//二级指针
    QStack <ChessNode> route;//所下的棋的路径
    int getSize();
    ChessNode** getBoard();//放置棋子 只有所放置位置的playerid=-1时才能放棋子
    ChessBoard(int size);//构建棋盘
    void addtoRoute(ChessNode c);//将下的棋压入栈中
    void PlaceChessNode(int x, int y, int id);//下棋

    ChessNode showChessNode(int x, int y);//返回某个棋子
    ChessNode showLatestNode();//返回最近下的一步棋
    void ResetLCN();//悔棋
    void ResetBoard();

};

#endif // CHESSBOARD_H
