/********************************************************************************
** Form generated from reading UI file 'Welcome.ui'
**
** Created by: Qt User Interface Compiler version 5.9.2
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_WELCOME_H
#define UI_WELCOME_H

#include <QtCore/QVariant>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QButtonGroup>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QMainWindow>
#include <QtWidgets/QMenu>
#include <QtWidgets/QMenuBar>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QStatusBar>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_Welcome
{
public:
    QAction *action1;
    QAction *action2;
    QAction *action3;
    QAction *action4;
    QWidget *centralwidget;
    QPushButton *pushButton;
    QPushButton *pushButton_2;
    QMenuBar *menubar;
    QMenu *menu;
    QStatusBar *statusbar;

    void setupUi(QMainWindow *Welcome)
    {
        if (Welcome->objectName().isEmpty())
            Welcome->setObjectName(QStringLiteral("Welcome"));
        Welcome->resize(800, 600);
        action1 = new QAction(Welcome);
        action1->setObjectName(QStringLiteral("action1"));
        action2 = new QAction(Welcome);
        action2->setObjectName(QStringLiteral("action2"));
        action3 = new QAction(Welcome);
        action3->setObjectName(QStringLiteral("action3"));
        action4 = new QAction(Welcome);
        action4->setObjectName(QStringLiteral("action4"));
        centralwidget = new QWidget(Welcome);
        centralwidget->setObjectName(QStringLiteral("centralwidget"));
        pushButton = new QPushButton(centralwidget);
        pushButton->setObjectName(QStringLiteral("pushButton"));
        pushButton->setGeometry(QRect(50, 160, 80, 15));
        pushButton_2 = new QPushButton(centralwidget);
        pushButton_2->setObjectName(QStringLiteral("pushButton_2"));
        pushButton_2->setGeometry(QRect(70, 190, 80, 15));
        Welcome->setCentralWidget(centralwidget);
        menubar = new QMenuBar(Welcome);
        menubar->setObjectName(QStringLiteral("menubar"));
        menubar->setGeometry(QRect(0, 0, 800, 17));
        menu = new QMenu(menubar);
        menu->setObjectName(QStringLiteral("menu"));
        Welcome->setMenuBar(menubar);
        statusbar = new QStatusBar(Welcome);
        statusbar->setObjectName(QStringLiteral("statusbar"));
        Welcome->setStatusBar(statusbar);

        menubar->addAction(menu->menuAction());
        menu->addSeparator();
        menu->addAction(action1);
        menu->addSeparator();
        menu->addAction(action2);
        menu->addSeparator();
        menu->addAction(action3);
        menu->addSeparator();
        menu->addAction(action4);
        menu->addSeparator();

        retranslateUi(Welcome);

        QMetaObject::connectSlotsByName(Welcome);
    } // setupUi

    void retranslateUi(QMainWindow *Welcome)
    {
        Welcome->setWindowTitle(QApplication::translate("Welcome", "MainWindow", Q_NULLPTR));
        action1->setText(QApplication::translate("Welcome", "\344\272\272\344\272\272\345\257\271\346\210\230", Q_NULLPTR));
        action2->setText(QApplication::translate("Welcome", "\344\272\272\346\234\272\345\257\271\346\210\230", Q_NULLPTR));
        action3->setText(QApplication::translate("Welcome", "\346\234\272\346\234\272\345\257\271\346\210\230", Q_NULLPTR));
        action4->setText(QApplication::translate("Welcome", "\347\275\221\347\273\234\345\257\271\346\210\230", Q_NULLPTR));
        pushButton->setText(QApplication::translate("Welcome", "\345\274\200\345\247\213\346\270\270\346\210\217", Q_NULLPTR));
        pushButton_2->setText(QApplication::translate("Welcome", "\351\200\200\345\207\272\346\270\270\346\210\217", Q_NULLPTR));
        menu->setTitle(QApplication::translate("Welcome", "\346\270\270\346\210\217\346\250\241\345\274\217", Q_NULLPTR));
    } // retranslateUi

};

namespace Ui {
    class Welcome: public Ui_Welcome {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_WELCOME_H
