#include "Server.h"
#include "ui_Server.h"
#include<QString>
#include"ChessBoard.h"
#include"ChessNode.h"
#include"Algorithm.h"
#include<QPainter>
#include<QPoint>
#include<QMouseEvent>
#include<QMessageBox>
#include<QPushButton>
#include<QLabel>
#include<QDebug>
#define BLACK 0
#define WHITE 1
#define NONE -1
const int BoardMargin = 40; // 棋盘边缘空隙
const int Noder = 15; // 棋子半径
const int Size=21;
const int BlockSize = 40; // 格子的大小
ChessBoard board1(Size);
Server::Server(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::Server)
{
    setMouseTracking(true);
    ui->setupUi(this);
    ui->label->move(350,920);
    ui->label->setFixedSize(150,50);
    ui->label->setText("提示:黑方执棋!");
    ui->labelBlack->move(35,850);
    ui->labelBlack->setFixedSize(150,50);
    ui->lineEditWrite->move(115,850);
    ui->lineEditRead->setFixedSize(300,50);
    ui->labelWhite->move(450,850);
    ui->labelWhite->setFixedSize(150,50);
    ui->lineEditRead->move(530,850);
    ui->lineEditWrite->setFixedSize(300,50);
    ui->buttonSend->move(200,920);
    ui->buttonSend->setFixedSize(100,50);
    ui->buttonClose->setFixedSize(100,50);
    ui->buttonClose->move(610,920);
    connect(ui->buttonSend,&QPushButton::clicked,this,mySlot1);
    connect(ui->buttonClose,&QPushButton::clicked,this,[=](){
        this->hide();
    });
    tcpServer=NULL;
    tcpSocket=NULL;
    tcpServer=new QTcpServer(this);
    tcpServer->listen(QHostAddress::Any,8888);//监听
    setWindowTitle("服务器:8888");
    setFixedSize(950,1020);
    connect(tcpServer,&QTcpServer::newConnection,[=](){
        //取出建立好连接的套接字
        tcpSocket=tcpServer->nextPendingConnection();//当前最近的那个套接字
        //获取对方的IP和端口
        QString ip=tcpSocket->peerAddress().toString();
        qint16 port=tcpSocket->peerPort();
        QString temp=QString("[%1:%2]:成功连接").arg(ip).arg(port);
        ui->lineEditRead->setText(temp);
        //取出以后才能传送数据
        connect(tcpSocket,&QTcpSocket::readyRead,[=](){
            //从通信套接字中取出内容
            QByteArray array=tcpSocket->readAll();
            char *ch=array.data();
           // qDebug()<<"ch[0]"<<ch[0]<<","<<"ch[2]"<<ch[2];
            int arrayRow;
            int arrayCol;
            if((int)ch[1]-48<0&&(int)ch[3]<=0){
            arrayRow=(int)ch[0]-48;
            arrayCol=(int)ch[2]-48;
             //qDebug()<<"ch[0]"<<ch[0]<<","<<"ch[2]"<<ch[2];
            }
            else if((int)ch[2]-48<0&&(int)ch[4]>0){
                int high1=(int)ch[0]-48;
                int low1=(int)ch[1]-48;
                //qDebug()<<"high1"<<high1<<"low1"<<low1;
                arrayRow=high1*10+low1;
                int high2=(int)ch[3]-48;
                int low2=(int)ch[4]-48;
                // qDebug()<<"ch[3]"<<ch[3]<<","<<"ch[4]"<<ch[4];
               //  qDebug()<<"high2"<<high2<<"low2"<<low2;
                arrayCol=high2*10+low2;
            }
            else if((int)ch[2]-48<0&&(int)ch[4]<=0){
                int high1=(int)ch[0]-48;
                int low1=(int)ch[1]-48;
                arrayRow=high1*10+low1;
                arrayCol=(int)ch[3]-48;
            }
            else if((int)ch[1]-48<0&&(int)ch[3]>0){
                arrayRow=(int)ch[0]-48;
                int high2=(int)ch[2]-48;
                int low2=(int)ch[3]-48;
                arrayCol=high2*10+low2;

            }
             //qDebug()<<"arrayRow"<<arrayRow<<","<<"arrayCol"<<arrayCol;
             ui->label->setText("提示:白方执棋!");
              board1.PlaceChessNode(arrayRow,arrayCol,WHITE);
              ui->label->setText("提示:黑方执棋!");
              if(algorithm.judge(board1,Size)==BLACK){
                   ui->label->setText("提示:黑棋胜利!");
                  board1.ResetBoard();
               }
               else if(algorithm.judge(board1,Size)==WHITE){
                 ui->label->setText("提示:白棋胜利!");
                 board1.ResetBoard();
               }


             update();
            ui->lineEditRead->setText(array);
        });
    });

}

Server::~Server()
{
    delete ui;
}
void Server::mySlot1(){
    emit ComeBack();
}
void Server::paintEvent(QPaintEvent *){
    QPainter painter(this);
      painter.setRenderHint(QPainter::Antialiasing, true); // 抗锯齿

      //画21条横线
    for(int i=1;i<=21;i++){
        painter.drawLine(QPoint(i*BlockSize,BlockSize),QPoint(i*BlockSize,21*BlockSize));

    }
    //画21条竖线
    for(int i=1;i<=21;i++){
        painter.drawLine(QPoint(BlockSize,i*BlockSize),QPoint(21*BlockSize,i*BlockSize));

    }


      //画鼠标光标
      if(boardRow>=0&&boardCol>=0){
          painter.setBrush(Qt::black);
    painter.drawEllipse(boardRow*BlockSize-6,boardCol*BlockSize-6,12,12);
    // qDebug()<<boardRow<<","<<boardCol;

      }
    for(int i=1;i<=21;i++){
        for(int j=1;j<=21;j++){
            if(board1.showChessNode(i,j).getId()==BLACK){
                painter.setBrush(Qt::black);
                painter.drawEllipse(i*BlockSize-Noder,j*BlockSize-Noder,30,30);
            }
            else if(board1.showChessNode(i,j).getId()==WHITE){
                painter.setBrush(Qt::white);
                painter.drawEllipse(i*BlockSize-Noder,j*BlockSize-Noder,30,30);
            }
        }
    }
}
void Server::mouseMoveEvent(QMouseEvent *ev){
    int mousex;
    mousex=ev->x();
    int mousey;
    mousey=ev->y();
   //  qDebug()<<mousex<<","<<mousey;
    if(mousex>=25&&mousex<=855&&mousey>=25&&mousey<=855){
        setCursor(Qt::BlankCursor);
        boardRow=(mousex-Noder)/40+1;
        boardCol=(mousey-Noder)/40+1;//像素点转换成棋盘坐标
       if(board1.showChessNode(boardRow,boardCol).getId()!=-1)
        setCursor(Qt::ForbiddenCursor);//展示图标坐标
       }
       else setCursor(Qt::ArrowCursor);
      update();
}
void Server::mouseReleaseEvent(QMouseEvent *ev){
   int mousex;
   mousex=ev->x();
   int mousey;
   mousey=ev->y();
   if(mousex>=20&&mousey>=20&&mousey<=890&&mousey<=890){
      boardRow=(mousex-Noder)/40+1;
      boardCol=(mousey-Noder)/40+1;//像素点转换成棋盘坐标

      if(board1.showChessNode(boardRow,boardCol).getId()==-1){
          int id;
          if(isblack){
                id=BLACK;

                QString str1="";
                str1+=QString::number(boardRow);
                str1+=",";
                str1+=QString::number(boardCol);
                ui->lineEditWrite->setText(str1);
                //获取编辑区内容
                QString str=ui->lineEditWrite->text();
                //给对方发送数据 使用tcpSocket  已经建立连接 str转字符数组
                tcpSocket->write(str.toUtf8().data());
                   ui->label->setText("提示:黑方执棋!");
                   board1.PlaceChessNode(boardRow,boardCol,id);//下棋
                   ui->label->setText("提示:白方执棋!");
                   if(tcpSocket==NULL){
                          return;
                      }


                    update();

            }
         if(algorithm.judge(board1,Size)==BLACK){
              ui->label->setText("提示:黑方胜利!");
             board1.ResetBoard();
          }
          else if(algorithm.judge(board1,Size)==WHITE){
             ui->label->setText("提示:白方胜利!");
            board1.ResetBoard();
          }

          update();
      }
   }
}
void Server::on_buttonSend_clicked()
{   /* if(tcpSocket==NULL){
        return;
    }
    //获取编辑区内容
    QString str=ui->lineEditWrite->text();
    //给对方发送数据 使用tcpSocket  已经建立连接 str转字符数组
    tcpSocket->write(str.toUtf8().data());*/

}

void Server::on_buttonClose_clicked()
{  //主动和客户端断开连接
    if(tcpSocket==NULL){
            return;
        }
    tcpSocket->disconnectFromHost();
    tcpSocket->close();
    tcpSocket=NULL;
}
