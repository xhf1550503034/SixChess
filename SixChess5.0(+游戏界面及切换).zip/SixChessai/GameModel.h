#ifndef GAMEMODEL_H
#define GAMEMODEL_H
enum GameMode{PVP,PVAI,AIVAI,NETWORK};

class GameModel
{
public:
    GameModel();
    GameMode mode;
};
//根据选择来进入不同的游戏模式
#endif // GAMEMODEL_H
