#ifndef SERVER_H
#define SERVER_H
#include"ChessBoard.h"
#include"ChessNode.h"
#include"Algorithm.h"
#include <QMainWindow>
#include<QTcpServer>//监听套接字
#include<QTcpSocket>//通信套接字
//服务器端需要两个套接字
namespace Ui {
class Server;
}

class Server : public QMainWindow
{
    Q_OBJECT

public:
    explicit Server(QWidget *parent = 0);
    ~Server();
    void paintEvent(QPaintEvent *);
    void mouseMoveEvent(QMouseEvent *);
    void mouseReleaseEvent(QMouseEvent *);
     Algorithm algorithm;
      bool isblack=true;
      int boardRow;
      int boardCol;
signals:
      void ComeBack();
private slots:
    void on_buttonSend_clicked();

    void on_buttonClose_clicked();
    void mySlot1();

private:
    Ui::Server *ui;
    QTcpServer *tcpServer;
    QTcpSocket *tcpSocket;
};

#endif // SERVER_H
