#include "Client.h"
#include "ui_Client.h"
#include<QHostAddress>
#include"ChessBoard.h"
#include"ChessNode.h"
#include"Algorithm.h"
#include<QPainter>
#include<QPoint>
#include<QMouseEvent>
#include<QMessageBox>
#include<QPushButton>
#include<QLabel>
#include<QDebug>
#include<QByteArray>
#define BLACK 0
#define WHITE 1
#define NONE -1
const int BoardMargin = 40; // 棋盘边缘空隙
const int Noder = 15; // 棋子半径
const int Size=21;
const int BlockSize = 40; // 格子的大小
ChessBoard board2(Size);
Client::Client(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::Client)
{
    ui->setupUi(this);
    setWindowTitle("客户端");
    setMouseTracking(true);
    setFixedSize(1200,1020);
    ui->label->move(350,920);
    ui->label->setFixedSize(150,50);
    ui->label->setText("提示:黑方执棋!");
    ui->labelPort->move(860,100);
    ui->labelPort->setFixedSize(100,50);//长 宽
    ui->lineEditPort->move(1000,100);
    ui->lineEditPort->setFixedSize(150,50);
    ui->labelIP->move(860,180);
    ui->labelIP->setFixedSize(100,50);
    ui->lineEditIP->move(1000,180);
    ui->lineEditIP->setFixedSize(150,50);
    ui->pushButtonConnect->move(1000,260);
    ui->pushButtonConnect->setFixedSize(100,50);
    ui->labelBlack->move(35,850);
    ui->labelBlack->setFixedSize(150,50);
    ui->lineEditRead->move(115,850);
    ui->lineEditRead->setFixedSize(300,50);
    ui->labelWhite->move(450,850);
    ui->labelWhite->setFixedSize(150,50);
    ui->lineEditWrite->move(530,850);
    ui->lineEditWrite->setFixedSize(300,50);
    ui->pushButtonSend->move(200,920);
    ui->pushButtonSend->setFixedSize(100,50);
    ui->pushButtonClose->setFixedSize(100,50);
    ui->pushButtonClose->move(610,920);
    connect(ui->pushButtonSend,&QPushButton::clicked,this,mySlot2);
    connect(ui->pushButtonClose,&QPushButton::clicked,this,[=](){
        this->hide();
    });
    tcpSocket=NULL;
    //分配空间 指定父对象
    tcpSocket=new QTcpSocket(this);
    connect(tcpSocket,&QTcpSocket::connected,[=](){
        ui->lineEditRead->setText("成功和服务器建立连接");
    });
    connect(tcpSocket,&QTcpSocket::readyRead,[=](){
        //获取对方发送的内容
        QByteArray array=tcpSocket->readAll();
        //追加到编辑区
        char *ch=array.data();
       // qDebug()<<"ch[0]"<<ch[0]<<","<<"ch[2]"<<ch[2];
        int arrayRow;
        int arrayCol;
        if((int)ch[1]-48<0&&(int)ch[3]<=0){
        arrayRow=(int)ch[0]-48;
        arrayCol=(int)ch[2]-48;
         //qDebug()<<"ch[0]"<<ch[0]<<","<<"ch[2]"<<ch[2];
        }
        else if((int)ch[2]-48<0&&(int)ch[4]>0){
            int high1=(int)ch[0]-48;
            int low1=(int)ch[1]-48;
            //qDebug()<<"high1"<<high1<<"low1"<<low1;
            arrayRow=high1*10+low1;
            int high2=(int)ch[3]-48;
            int low2=(int)ch[4]-48;
            // qDebug()<<"ch[3]"<<ch[3]<<","<<"ch[4]"<<ch[4];
            // qDebug()<<"high2"<<high2<<"low2"<<low2;
            arrayCol=high2*10+low2;
        }
        else if((int)ch[2]-48<0&&(int)ch[4]<=0){
            int high1=(int)ch[0]-48;
            int low1=(int)ch[1]-48;
            arrayRow=high1*10+low1;
            arrayCol=(int)ch[3]-48;
        }
        else if((int)ch[1]-48<0&&(int)ch[3]>0){
            arrayRow=(int)ch[0]-48;
            int high2=(int)ch[2]-48;
            int low2=(int)ch[3]-48;
            arrayCol=high2*10+low2;

        }
         //qDebug()<<"arrayRow"<<arrayRow<<","<<"arrayCol"<<arrayCol;
        ui->label->setText("提示:黑方执棋!");
          board2.PlaceChessNode(arrayRow,arrayCol,BLACK);
           ui->label->setText("提示:白方执棋!");
          if(algorithm.judge(board2,Size)==BLACK){
             // QMessageBox::warning(NULL,"提示","黑棋胜利");
              ui->label->setText("提示:黑棋胜利！");
              board2.ResetBoard();
          }
          else if(algorithm.judge(board2,Size)==WHITE){
              //QMessageBox::warning(NULL,"提示","白棋胜利");
               ui->label->setText("提示:白棋胜利！");
             board2.ResetBoard();
          }

          update();
        ui->lineEditRead->setText(array);
        update();
    });
}
void Client::mySlot2(){
    emit ComeBack();
}
Client::~Client()
{
    delete ui;
}
void Client::paintEvent(QPaintEvent *){
    QPainter painter(this);
      painter.setRenderHint(QPainter::Antialiasing, true); // 抗锯齿

      //画21条横线
    for(int i=1;i<=21;i++){
        painter.drawLine(QPoint(i*BlockSize,BlockSize),QPoint(i*BlockSize,21*BlockSize));

    }
    //画21条竖线
    for(int i=1;i<=21;i++){
        painter.drawLine(QPoint(BlockSize,i*BlockSize),QPoint(21*BlockSize,i*BlockSize));

    }


      //画鼠标光标
      if(boardRow>=0&&boardCol>=0){
          painter.setBrush(Qt::white);
    painter.drawEllipse(boardRow*BlockSize-6,boardCol*BlockSize-6,12,12);
     //qDebug()<<boardRow<<","<<boardCol;

      }
    for(int i=1;i<=21;i++){
        for(int j=1;j<=21;j++){
            if(board2.showChessNode(i,j).getId()==BLACK){
                painter.setBrush(Qt::black);
                painter.drawEllipse(i*BlockSize-Noder,j*BlockSize-Noder,30,30);
            }
            else if(board2.showChessNode(i,j).getId()==WHITE){
                painter.setBrush(Qt::white);
                painter.drawEllipse(i*BlockSize-Noder,j*BlockSize-Noder,30,30);
            }
        }
    }
}
void Client::mouseMoveEvent(QMouseEvent *ev){
    int mousex;
    mousex=ev->x();
    int mousey;
    mousey=ev->y();
     //qDebug()<<mousex<<","<<mousey;
    if(mousex>=25&&mousex<=855&&mousey>=25&&mousey<=855){
        setCursor(Qt::BlankCursor);
        boardRow=(mousex-Noder)/40+1;
        boardCol=(mousey-Noder)/40+1;//像素点转换成棋盘坐标
       if(board2.showChessNode(boardRow,boardCol).getId()!=-1)
        setCursor(Qt::ForbiddenCursor);//展示图标坐标
       }
       else setCursor(Qt::ArrowCursor);
      update();
}
void Client::mouseReleaseEvent(QMouseEvent *ev){
   int mousex;
   mousex=ev->x();
   int mousey;
   mousey=ev->y();
   if(mousex>=20&&mousey>=20&&mousey<=890&&mousey<=890){
      boardRow=(mousex-Noder)/40+1;
      boardCol=(mousey-Noder)/40+1;//像素点转换成棋盘坐标
    // qDebug()<<boardRow<<","<<boardCol;
      if(board2.showChessNode(boardRow,boardCol).getId()==-1){
          int id;

                id=WHITE;
                //获取编辑框内容
                QString str2="";
                str2+=QString::number(boardRow);
                str2+=",";
                str2+=QString::number(boardCol);
                ui->lineEditWrite->setText(str2);
                  QString str=ui->lineEditWrite->text();
                  //发送数据
                  tcpSocket->write(str.toUtf8().data());
                  ui->label->setText("提示:白方执棋!");
                  board2.PlaceChessNode(boardRow,boardCol,id);
                  ui->label->setText("提示:黑方执棋!");
                  //下棋


                    update();
          if(algorithm.judge(board2,Size)==BLACK){
              ui->label->setText("提示:黑棋胜利！");
              board2.ResetBoard();
          }
          else if(algorithm.judge(board2,Size)==WHITE){
              ui->label->setText("提示:白棋胜利！");
             board2.ResetBoard();
          }

          update();
      }
   }
}
void Client::on_pushButtonSend_clicked()
{
//  //获取编辑框内容
//    QString str=ui->lineEditWrite->text();
//    //发送数据
//    tcpSocket->write(str.toUtf8().data());

}


void Client::on_pushButtonConnect_clicked()
{
    //获取服务器IP和端口
    QString IP=ui->lineEditIP->text();
    qint16 port=ui->lineEditPort->text().toInt();
    //主动和服务器建立连接
    tcpSocket->connectToHost(QHostAddress(IP),port);
}

void Client::on_pushButtonClose_clicked()
{
    //主动和对方断开连接
    tcpSocket->disconnectFromHost();
    tcpSocket->close();
}
