#ifndef WELCOME_H
#define WELCOME_H
#include"Server.h"
#include"Client.h"
#include <QMainWindow>
#include"mainwindow.h"
#include"GameModel.h"
#include"aiVp.h"
#include"aiPK.h"
namespace Ui {
class Welcome;
}

class Welcome : public QMainWindow
{
    Q_OBJECT


public:
    explicit Welcome(QWidget *parent = 0);
    ~Welcome();
    void paintEvent(QPaintEvent *);
    GameModel g;
    Server s;
    Client c;
    MainWindow m;
    aiPK a;
    aiVp a1;


private slots:
    void on_pushButton_2_clicked();

    void on_action1_triggered();

    void on_action2_triggered();

    void on_action3_triggered();

    void on_action4_triggered();

    void on_pushButton_clicked();


private:
    Ui::Welcome *ui;
};

#endif // WELCOME_H
