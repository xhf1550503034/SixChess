#include "ChessBoard.h"
#include"ChessNode.h"
#include<stack>
int ChessBoard::getSize() {
       return size;
   }
ChessNode ** ChessBoard::getBoard() {
       return chessNodes;
   }
ChessBoard::ChessBoard(int size) {
       this->size = size;
       chessNodes = new ChessNode * [size + 2];
       for (int i = 0; i < size + 2; i++) {
           chessNodes[i] = new ChessNode [size + 2];
           for (int j = 0; j < size + 2; j++) {
               chessNodes[i][j].setChessNode(i, j, -1);
           }
       }
   }
//构建棋盘

void ChessBoard::PlaceChessNode(int x, int y, int id) {
       if (chessNodes[x][y].getId()==-1 && x >= 1 && x <= size && y >= 1 && y <= size) {
           chessNodes[x][y].setChessNode(x, y, id);
           addtoRoute(chessNodes[x][y]);
       }
   }//放置棋子 只有所放置位置的playerid=-1时才能放棋子
 ChessNode ChessBoard::showChessNode(int x, int y) {
       if (x >= 1 && x <= size && y >= 1 && y <= size) {
           return chessNodes[x][y];
       }
       else return chessNodes[0][0];
   }
void ChessBoard::addtoRoute(ChessNode c) {
       route.push(c);
   }//将下的棋压入栈中
ChessNode ChessBoard::showLatestNode() {
       if (!route.empty()) {
           ChessNode lc = route.top();
           return lc;
       }
       else {
           return chessNodes[0][0];
       }
   }//返回最近下的一步棋

 void ChessBoard::ResetLCN() {
       if (!route.empty()) {
           ChessNode c = route.top();
           chessNodes[c.getX()][c.getY()].setId(-1);
           route.pop();
       }

   }//悔棋
 void ChessBoard::ResetBoard(){
     while(!route.empty()){
        ResetLCN();
     }
 }

