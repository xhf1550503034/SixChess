/********************************************************************************
** Form generated from reading UI file 'Server.ui'
**
** Created by: Qt User Interface Compiler version 5.9.2
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_SERVER_H
#define UI_SERVER_H

#include <QtCore/QVariant>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QButtonGroup>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QMainWindow>
#include <QtWidgets/QMenuBar>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QStatusBar>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_Server
{
public:
    QWidget *centralwidget;
    QPushButton *buttonSend;
    QPushButton *buttonClose;
    QLabel *labelBlack;
    QLabel *labelWhite;
    QLineEdit *lineEditRead;
    QLineEdit *lineEditWrite;
    QLabel *label;
    QMenuBar *menubar;
    QStatusBar *statusbar;

    void setupUi(QMainWindow *Server)
    {
        if (Server->objectName().isEmpty())
            Server->setObjectName(QStringLiteral("Server"));
        Server->resize(800, 600);
        centralwidget = new QWidget(Server);
        centralwidget->setObjectName(QStringLiteral("centralwidget"));
        buttonSend = new QPushButton(centralwidget);
        buttonSend->setObjectName(QStringLiteral("buttonSend"));
        buttonSend->setGeometry(QRect(214, 537, 80, 16));
        buttonClose = new QPushButton(centralwidget);
        buttonClose->setObjectName(QStringLiteral("buttonClose"));
        buttonClose->setGeometry(QRect(506, 537, 80, 16));
        labelBlack = new QLabel(centralwidget);
        labelBlack->setObjectName(QStringLiteral("labelBlack"));
        labelBlack->setGeometry(QRect(50, 510, 41, 9));
        labelWhite = new QLabel(centralwidget);
        labelWhite->setObjectName(QStringLiteral("labelWhite"));
        labelWhite->setGeometry(QRect(70, 550, 41, 9));
        lineEditRead = new QLineEdit(centralwidget);
        lineEditRead->setObjectName(QStringLiteral("lineEditRead"));
        lineEditRead->setGeometry(QRect(50, 60, 113, 20));
        lineEditWrite = new QLineEdit(centralwidget);
        lineEditWrite->setObjectName(QStringLiteral("lineEditWrite"));
        lineEditWrite->setGeometry(QRect(40, 200, 113, 20));
        label = new QLabel(centralwidget);
        label->setObjectName(QStringLiteral("label"));
        label->setGeometry(QRect(100, 250, 41, 9));
        Server->setCentralWidget(centralwidget);
        menubar = new QMenuBar(Server);
        menubar->setObjectName(QStringLiteral("menubar"));
        menubar->setGeometry(QRect(0, 0, 800, 17));
        Server->setMenuBar(menubar);
        statusbar = new QStatusBar(Server);
        statusbar->setObjectName(QStringLiteral("statusbar"));
        Server->setStatusBar(statusbar);

        retranslateUi(Server);

        QMetaObject::connectSlotsByName(Server);
    } // setupUi

    void retranslateUi(QMainWindow *Server)
    {
        Server->setWindowTitle(QApplication::translate("Server", "MainWindow", Q_NULLPTR));
        buttonSend->setText(QApplication::translate("Server", "\350\277\224\345\233\236\344\270\273\350\217\234\345\215\225", Q_NULLPTR));
        buttonClose->setText(QApplication::translate("Server", "\351\200\200\345\207\272\346\270\270\346\210\217", Q_NULLPTR));
        labelBlack->setText(QApplication::translate("Server", "\351\273\221\346\243\213\345\235\220\346\240\207:", Q_NULLPTR));
        labelWhite->setText(QApplication::translate("Server", "\347\231\275\346\243\213\345\235\220\346\240\207:", Q_NULLPTR));
        label->setText(QApplication::translate("Server", "TextLabel", Q_NULLPTR));
    } // retranslateUi

};

namespace Ui {
    class Server: public Ui_Server {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_SERVER_H
