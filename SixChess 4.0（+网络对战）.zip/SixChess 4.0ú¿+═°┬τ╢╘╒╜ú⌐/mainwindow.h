#ifndef MAINWINDOW_H
#define MAINWINDOW_H
#include <QMainWindow>
#include"ChessBoard.h"
#include"ChessNode.h"
#include"Algorithm.h"
#include<QLabel>
#include"ChessAI.h"
#include<QTimer>
#include"GameModel.h"
#include<QPushButton>
class MainWindow : public QMainWindow
{
    Q_OBJECT

    int boardRow;
    int boardCol;
public:

    MainWindow(QWidget *parent = 0);
    ~MainWindow();
    //绘制棋盘
    void paintEvent(QPaintEvent *);
    void mouseMoveEvent(QMouseEvent *);
    void mouseReleaseEvent(QMouseEvent *);
      QLabel * lb_white_position=new QLabel(this);

      QLabel * lb_black_position=new QLabel(this);
      QPushButton *button1=new QPushButton(this);
     Algorithm algorithm;
     GameModel g1;
     ChessAI ai;
     //void updateGameBoard(int board[23][23]);
     int aiRow;
     int aiCol;
    bool isblack;
    void actionByAI(int&aiRow, int&aiCol);
signals:
    void ComeBack();
public slots:
    void oneChessByAIW();
    void oneChessByAIB();
    void mySlot1();
    void mySlot2();
};


#endif // MAINWINDOW_H
