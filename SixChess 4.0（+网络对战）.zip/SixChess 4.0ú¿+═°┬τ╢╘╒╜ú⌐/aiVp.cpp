#include "aiVp.h"
#include"ChessBoard.h"
#include"ChessNode.h"
#include"Algorithm.h"
#include"ChessAI.h"
#include<QPainter>
#include<QPoint>
#include<QMouseEvent>
#include<QMessageBox>
#include<QPushButton>
#include<QObject>
#include<QString>
#include<QLabel>
#include<QDebug>
#include <time.h>
#include <stdlib.h>
#include<QTimer>
#define BLACK 0
#define WHITE 1
#define NONE -1
const int BoardMargin = 40; // 棋盘边缘空隙
const int Noder = 15; // 棋子半径
const int Size=21;
const int BlockSize = 40; // 格子的大小
const int AI_THINK_TIME=1000;
ChessBoard board3(Size);
void aiVp::paintEvent(QPaintEvent *){
    QPainter painter(this);
      painter.setRenderHint(QPainter::Antialiasing, true); // 抗锯齿
      if(isblack)painter.setBrush(Qt::black);
        if(!isblack) painter.setBrush(Qt::white);
        //画鼠标光标
        if(boardRow>=0&&boardCol>=0){
      painter.drawEllipse(boardRow*BlockSize-6,boardCol*BlockSize-6,12,12);
        }
      //画21条横线
    for(int i=1;i<=21;i++){
        painter.drawLine(QPoint(i*BlockSize,BlockSize),QPoint(i*BlockSize,21*BlockSize));

    }
    //画21条竖线
    for(int i=1;i<=21;i++){
        painter.drawLine(QPoint(BlockSize,i*BlockSize),QPoint(21*BlockSize,i*BlockSize));

    }
    for(int i=1;i<=21;i++){
        for(int j=1;j<=21;j++){
            if(board3.showChessNode(i,j).getId()==BLACK){
                painter.setBrush(Qt::black);
                painter.drawEllipse(i*BlockSize-Noder,j*BlockSize-Noder,30,30);
            }
            else if(board3.showChessNode(i,j).getId()==WHITE){
                painter.setBrush(Qt::white);
                painter.drawEllipse(i*BlockSize-Noder,j*BlockSize-Noder,30,30);
            }
        }
    }
}
void aiVp::oneChessByAIW(){
   this->actionByAI(aiRow,aiCol);
   int id=WHITE;
   board3.PlaceChessNode(aiRow,aiCol,id);
   ai.gameBoard[aiRow][aiCol]=WHITE;
}
void aiVp::actionByAI(int &aiRow, int &aiCol)
{
    // 计算评分
    ai.calculateScore();

    // 从评分中找出最大分数的位置
    int maxScore = 0;
    std::vector<std::pair<int, int>> maxPoints;

    for (int row = 1; row <=21; row++)
        for (int col = 1; col <=21; col++)
        {
            // 前提是这个坐标是空的
            if (ai.gameBoard[row][col] == NONE)
            {
                if (ai.scoreBoard[row][col] > maxScore)          // 找最大的数和坐标
                {
                    maxPoints.clear();
                    maxScore = ai.scoreBoard[row][col];
                    maxPoints.push_back(std::make_pair(row, col));
                }
                else if (ai.scoreBoard[row][col] == maxScore)     // 如果有多个最大的数，都存起来
                    maxPoints.push_back(std::make_pair(row, col));
            }
        }

    // 随机落子，如果有多个点的话
    srand((unsigned)time(0));
    int index = rand() % maxPoints.size();

    std::pair<int, int> pointPair = maxPoints.at(index);
    aiRow = pointPair.first; // 记录落子点
    aiCol = pointPair.second;


}

void aiVp::mySlot1(){
    board3.ResetLCN();
    update();
    ChessNode tmp=board3.showLatestNode();
    if(tmp.getId()==BLACK){
        isblack=false;
    }
    else{
        isblack=true;
    }//该方悔棋之后还由该方下
}
void aiVp::mySlot2(){
    emit ComeBack();
}
void aiVp::mouseMoveEvent(QMouseEvent *ev){
    int mousex;
    mousex=ev->x();
    int mousey;
    mousey=ev->y();
    if(mousex>=25&&mousex<=855&&mousey>=25&&mousey<=855){
        setCursor(Qt::BlankCursor);
        boardRow=(mousex-Noder)/40+1;
        boardCol=(mousey-Noder)/40+1;//像素点转换成棋盘坐标
       if(board3.showChessNode(boardRow,boardCol).getId()!=-1)
        setCursor(Qt::ForbiddenCursor);//展示图标坐标
       }
       else setCursor(Qt::ArrowCursor);
      update();
}

void aiVp::mouseReleaseEvent(QMouseEvent *ev){
   int mousex;
   mousex=ev->x();
   int mousey;
   mousey=ev->y();
   if(mousex>=20&&mousey>=20&&mousey<=890&&mousey<=890){
      boardRow=(mousex-Noder)/40+1;
      boardCol=(mousey-Noder)/40+1;//像素点转换成棋盘坐标
    if(board3.showChessNode(boardRow,boardCol).getId()==-1){
          int id;
          if(isblack){//黑方下棋
                id=BLACK;


                    board3.PlaceChessNode(boardRow,boardCol,id);//下棋
                    ai.gameBoard[boardRow][boardCol]=BLACK;
                    lb_black_position->move(950,300);
                     lb_black_position->setText(" ");
                     QString str2="";
                     str2+=QString::number(boardRow);
                     str2+=",";
                     str2+=QString::number(boardCol);
                     lb_black_position->setText(str2);
                      // qDebug()<<"isblack="<<isblack;


                isblack=!isblack;
                 update();
            }
          if(!isblack){

              id=WHITE;

                  QTimer::singleShot(AI_THINK_TIME,this,SLOT(oneChessByAIW()));

                  lb_white_position->move(950,400);
                  lb_white_position->setText(" ");
                  QString str1="";
                  str1+=QString::number(aiRow);
                  str1+=",";
                  str1+=QString::number(aiCol);
                  lb_white_position->setText(str1);
                 // qDebug()<<"!isblack="<<isblack;
                  isblack=!isblack;
                  update();
          }

          if(algorithm.judge(board3,Size)==BLACK){
              QMessageBox::warning(NULL,"提示","黑棋胜利");
              board3.ResetBoard();
          }
          else if(algorithm.judge(board3,Size)==WHITE){
              QMessageBox::warning(NULL,"提示","白棋胜利");
             board3.ResetBoard();
          }
          else{
              bool flag=true;
              for(int i=0;i<23;i++){
                  for(int j=0;j<23;j++){
                      bool flag1=(ai.gameBoard[i][j]!=NONE);
                      flag=flag&&flag1;

                  }
              }
              if(flag){
                  QMessageBox::warning(NULL,"提示","和局");
                 board3.ResetBoard();//判断是否和局
              }
          }

          update();
      }
   }
}

aiVp::aiVp(QWidget *parent) : QMainWindow(parent)
{   setWindowTitle("六子棋");
    setMouseTracking(true); // 设置鼠标追踪
    isblack=true;
    // 设置棋盘大小
        setFixedSize(BoardMargin * 2 + BlockSize * Size+350, BoardMargin * 2 + BlockSize * Size);
        QPushButton *button=new QPushButton(this);
        button->setText("悔棋");
        button->setFixedWidth(100);
        button->setFixedHeight(70);
        button->move(950,400);
        connect(button,QPushButton::clicked,this,&aiVp::mySlot1);
         QPushButton *button1=new QPushButton(this);


        button1->setText("返回主菜单");
        button1->setFixedWidth(100);
        button1->setFixedHeight(70);
        button1->move(880,650);
         QPushButton *button2=new QPushButton(this);
         button2->setText("退出游戏");
         button2->setFixedWidth(100);
         button2->setFixedHeight(70);
         button2->move(1100,650);
          connect(button1,QPushButton::clicked,this,&aiVp::mySlot2);
          connect(button2,QPushButton::clicked,this,[=](){
              this->hide();

          });
       QLabel *blackChess=new QLabel(this);
        blackChess->setText("黑棋坐标:");
      QLabel *whiteChess=new QLabel(this);
        whiteChess->setText("白棋坐标:");
        blackChess->move(950,250);
        whiteChess->move(950,350);
}
