#include "ChessNode.h"

ChessNode::ChessNode()
{

}
void ChessNode::SetX(int x) {
           location_x = x;
       }
void ChessNode::setY(int y) {
           location_y = y;
       }
void ChessNode::setId(int id) {
           playerid = id;
       }
int ChessNode::getX() {
           return location_x;
       }
int ChessNode::getY() {
           return location_y;
       }
int ChessNode::getId() {
           return playerid;
       }
void ChessNode::setChessNode(int x, int y,int id) {
           location_x = x;
           location_y = y;
           playerid = id;

       }
