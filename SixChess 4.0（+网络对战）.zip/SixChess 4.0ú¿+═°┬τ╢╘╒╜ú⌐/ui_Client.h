/********************************************************************************
** Form generated from reading UI file 'Client.ui'
**
** Created by: Qt User Interface Compiler version 5.9.2
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_CLIENT_H
#define UI_CLIENT_H

#include <QtCore/QVariant>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QButtonGroup>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QMainWindow>
#include <QtWidgets/QMenuBar>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QStatusBar>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_Client
{
public:
    QWidget *centralwidget;
    QLabel *labelBlack;
    QLabel *labelPort;
    QLineEdit *lineEditPort;
    QLineEdit *lineEditIP;
    QLabel *labelIP;
    QPushButton *pushButtonSend;
    QPushButton *pushButtonConnect;
    QPushButton *pushButtonClose;
    QLabel *labelWhite;
    QLineEdit *lineEditRead;
    QLineEdit *lineEditWrite;
    QLabel *label;
    QMenuBar *menubar;
    QStatusBar *statusbar;

    void setupUi(QMainWindow *Client)
    {
        if (Client->objectName().isEmpty())
            Client->setObjectName(QStringLiteral("Client"));
        Client->resize(800, 600);
        centralwidget = new QWidget(Client);
        centralwidget->setObjectName(QStringLiteral("centralwidget"));
        labelBlack = new QLabel(centralwidget);
        labelBlack->setObjectName(QStringLiteral("labelBlack"));
        labelBlack->setGeometry(QRect(6, 514, 41, 16));
        labelPort = new QLabel(centralwidget);
        labelPort->setObjectName(QStringLiteral("labelPort"));
        labelPort->setGeometry(QRect(6, 6, 50, 16));
        lineEditPort = new QLineEdit(centralwidget);
        lineEditPort->setObjectName(QStringLiteral("lineEditPort"));
        lineEditPort->setGeometry(QRect(90, 6, 91, 22));
        lineEditIP = new QLineEdit(centralwidget);
        lineEditIP->setObjectName(QStringLiteral("lineEditIP"));
        lineEditIP->setGeometry(QRect(90, 32, 91, 22));
        labelIP = new QLabel(centralwidget);
        labelIP->setObjectName(QStringLiteral("labelIP"));
        labelIP->setGeometry(QRect(6, 32, 41, 16));
        pushButtonSend = new QPushButton(centralwidget);
        pushButtonSend->setObjectName(QStringLiteral("pushButtonSend"));
        pushButtonSend->setGeometry(QRect(6, 540, 80, 16));
        pushButtonConnect = new QPushButton(centralwidget);
        pushButtonConnect->setObjectName(QStringLiteral("pushButtonConnect"));
        pushButtonConnect->setGeometry(QRect(714, 35, 80, 16));
        pushButtonClose = new QPushButton(centralwidget);
        pushButtonClose->setObjectName(QStringLiteral("pushButtonClose"));
        pushButtonClose->setGeometry(QRect(714, 540, 80, 16));
        labelWhite = new QLabel(centralwidget);
        labelWhite->setObjectName(QStringLiteral("labelWhite"));
        labelWhite->setGeometry(QRect(6, 527, 41, 16));
        lineEditRead = new QLineEdit(centralwidget);
        lineEditRead->setObjectName(QStringLiteral("lineEditRead"));
        lineEditRead->setGeometry(QRect(100, 100, 113, 20));
        lineEditRead->setReadOnly(true);
        lineEditWrite = new QLineEdit(centralwidget);
        lineEditWrite->setObjectName(QStringLiteral("lineEditWrite"));
        lineEditWrite->setGeometry(QRect(100, 150, 113, 20));
        label = new QLabel(centralwidget);
        label->setObjectName(QStringLiteral("label"));
        label->setGeometry(QRect(120, 210, 41, 9));
        Client->setCentralWidget(centralwidget);
        menubar = new QMenuBar(Client);
        menubar->setObjectName(QStringLiteral("menubar"));
        menubar->setGeometry(QRect(0, 0, 800, 17));
        Client->setMenuBar(menubar);
        statusbar = new QStatusBar(Client);
        statusbar->setObjectName(QStringLiteral("statusbar"));
        Client->setStatusBar(statusbar);

        retranslateUi(Client);

        QMetaObject::connectSlotsByName(Client);
    } // setupUi

    void retranslateUi(QMainWindow *Client)
    {
        Client->setWindowTitle(QApplication::translate("Client", "MainWindow", Q_NULLPTR));
        labelBlack->setText(QApplication::translate("Client", "\351\273\221\346\243\213\345\235\220\346\240\207:", Q_NULLPTR));
        labelPort->setText(QApplication::translate("Client", "\346\234\215\345\212\241\345\231\250\347\253\257\345\217\243:", Q_NULLPTR));
        lineEditPort->setText(QApplication::translate("Client", "8888", Q_NULLPTR));
        lineEditIP->setText(QApplication::translate("Client", "127.0.0.1", Q_NULLPTR));
        labelIP->setText(QApplication::translate("Client", "\346\234\215\345\212\241\345\231\250IP:", Q_NULLPTR));
        pushButtonSend->setText(QApplication::translate("Client", "\350\277\224\345\233\236\344\270\273\350\217\234\345\215\225", Q_NULLPTR));
        pushButtonConnect->setText(QApplication::translate("Client", "\350\277\236\346\216\245", Q_NULLPTR));
        pushButtonClose->setText(QApplication::translate("Client", "\351\200\200\345\207\272\346\270\270\346\210\217", Q_NULLPTR));
        labelWhite->setText(QApplication::translate("Client", "\347\231\275\346\243\213\345\235\220\346\240\207:", Q_NULLPTR));
        label->setText(QApplication::translate("Client", "TextLabel", Q_NULLPTR));
    } // retranslateUi

};

namespace Ui {
    class Client: public Ui_Client {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_CLIENT_H
