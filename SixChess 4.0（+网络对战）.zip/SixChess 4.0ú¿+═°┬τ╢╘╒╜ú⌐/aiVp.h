#ifndef AIVP_H
#define AIVP_H
#include <QMainWindow>
#include"ChessBoard.h"
#include"ChessNode.h"
#include"Algorithm.h"
#include<QLabel>
#include"ChessAI.h"
#include<QTimer>
#include"GameModel.h"
#include <QMainWindow>

class aiVp : public QMainWindow
{
    Q_OBJECT
    int boardRow;
    int boardCol;
public:
    explicit aiVp(QWidget *parent = nullptr);
    void paintEvent(QPaintEvent *);
    void mouseMoveEvent(QMouseEvent *);
    void mouseReleaseEvent(QMouseEvent *);
      QLabel * lb_white_position=new QLabel(this);

      QLabel * lb_black_position=new QLabel(this);
     Algorithm algorithm;
     GameModel g1;
     ChessAI ai;

     int aiRow;
     int aiCol;
    bool isblack;

    void actionByAI(int&aiRow, int&aiCol);

signals:
    void ComeBack();

public slots:
    void oneChessByAIW();
    void mySlot1();
    void mySlot2();

};

#endif // AIVP_H
