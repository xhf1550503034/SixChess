#ifndef CLIENT_H
#define CLIENT_H
#include <QMainWindow>
#include<QTcpSocket>//通信套接字
#include"ChessBoard.h"
#include"ChessNode.h"
#include"Algorithm.h"
namespace Ui {
class Client;
}

class Client : public QMainWindow
{
    Q_OBJECT

public:
    explicit Client(QWidget *parent = 0);
    ~Client();
    void paintEvent(QPaintEvent *);
    void mouseMoveEvent(QMouseEvent *);
    void mouseReleaseEvent(QMouseEvent *);
     Algorithm algorithm;
      bool isblack=true;
      int boardRow;
      int boardCol;
signals:
      void ComeBack();

private slots:
    void on_pushButtonSend_clicked();

    void on_pushButtonConnect_clicked();

    void on_pushButtonClose_clicked();
    void mySlot2();

private:
    Ui::Client *ui;
    QTcpSocket *tcpSocket;
};

#endif // CLIENT_H
