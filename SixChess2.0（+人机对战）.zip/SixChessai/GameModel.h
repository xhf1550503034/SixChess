#ifndef GAMEMODEL_H
#define GAMEMODEL_H


class GameModel
{
public:
    GameModel();
};

#endif // GAMEMODEL_H