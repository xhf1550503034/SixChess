#ifndef CHESSAI_H
#define CHESSAI_H


class ChessAI
{
public:
    ChessAI();
    int scoreBoard[23][23];
    int gameBoard[23][23];
    void initializeScoreBoard(int score[23][23]);
    void initializeGameBoard(int game[23][23]);
    //void updateBoard(int row,int col);
    void calculateScore();
};

#endif // CHESSAI_H
