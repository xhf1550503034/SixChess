#include "GameModel.h"

GameModel::GameModel()
{

}
