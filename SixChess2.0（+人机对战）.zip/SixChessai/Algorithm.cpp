#include "Algorithm.h"
#include<QString>
#include <iostream>
#define BLACK 0
#define WHITE 1
Algorithm::Algorithm()
{

}
bool Algorithm::bKMP(QString longstr, QString shortstr) {
    QByteArray c1 = longstr.toLatin1();
    char* longarr=c1.data();
    QByteArray c2 = shortstr.toLatin1();
    char* shortarr = c2.data();
       if (longstr.length() < shortstr.length()) {
           return false;
       }
       else {
           for (int i = 0; i < longstr.length();) {
               int tmp = i;
               for (int j = 0; j < shortstr.length();) {
                   if (longarr[i] == shortarr[j]) {
                       i++; j++;
                       if (j == shortstr.length()) {
                           return true;
                       }
                   }
                   else {
                       j = 0; i = tmp + 1;
                       break;
                   }
               }
           }
       }
       return false;
   }//返回bool类型的KMP算法 即长字符串中是否含有短字符串
   int Algorithm::iKMP(QString longstr, QString shortstr) {
       QByteArray c1 = longstr.toLatin1();
       char* longarr=c1.data();
       QByteArray c2 = shortstr.toLatin1();
       char* shortarr = c2.data();
       int count = 0;
       if (longstr.length() < shortstr.length()) {
           return 0;
       }
       else {
           for (int i = 0; i < longstr.length();) {
               int tmp = i;
               for (int j = 0; j < shortstr.length();) {

                   if (longarr[i] == shortarr[j]) {
                       i++; j++;
                       if (j == shortstr.length()) {
                           count++;
                           j = 0; i = tmp + 1;
                           break;
                       }
                   }

                   else {
                       j = 0; i = tmp + 1;
                       break;
                   }

               }
           }
       }
       return count;

   }//返回int类型的KMP算法 即长字符串中有几个短字符串

   QString Algorithm::strReverse(QString str) {
      QString strr = "";
       for (int i = str.length() - 1; i >= 0; i--) {
           strr += str.at(i);
       }//最后一位是'\0';
       return strr;
   }
   QString Algorithm::NodeTranslate(ChessNode c) {
           QString str;
           if (c.getId() == -1) {
               str = "#";
           }
           else if (c.getId() == BLACK) {
               str = "x";
           }

           else if(c.getId()== 1){
               str ="o";
           }
           else {
               str = "";
           }
           return str;
       }
   QString * Algorithm::ScanNode(ChessBoard board, int size, ChessNode** node) {
       QString * str=new QString[8];
       for (int i = 0; i < 8;i++) {
           str[i] = "";

       }
       //str[0]从左到右扫描
       for (int i = 1; i <= size; i++) {
           str[0] += NodeTranslate(node[board.showLatestNode().getX()][i]);
       }
       //str[1]从上到下扫描
       for (int i = 1; i <= size; i++) {
           str[1] += NodeTranslate(node[i][board.showLatestNode().getY()]);
       }
       //str[2]从左上到右下扫描
       QString tmp = "";
       for (int i = board.showLatestNode().getX(), j = board.showLatestNode().getY(); i >= 1 && j >= 1; i--, j--) {
           tmp += NodeTranslate(node[i][j]);
       }
       str[2] += strReverse(tmp);
       for (int i = board.showLatestNode().getX()+1, j = board.showLatestNode().getY()+1; i <= size && j <=size; i++, j++) {
           str[2] += NodeTranslate(node[i][j]);
       }
       //str[3]从左下到右上扫描
       QString tmp1 = "";
       for (int i = board.showLatestNode().getX(), j = board.showLatestNode().getY(); i<=size && j >= 1; i++, j--) {
           tmp1 += NodeTranslate(node[i][j]);
       }
       str[3] += strReverse(tmp1);
       for (int i = board.showLatestNode().getX()-1, j = board.showLatestNode().getY()+1; i >= 1 && j <= size; i--, j++) {
           str[3] += NodeTranslate(node[i][j]);
       }
       for (int i = 4; i < 8; i++) {
           str[i] = strReverse(str[i - 4]);
       }
       return str;
   }



   int Algorithm::judge(ChessBoard board, int size) {

      QString * str = ScanNode(board, size, board.getBoard());

      //判断长连禁手
      bool flag[4] = { false,false,false,false };
      bool flag1 = false;
      for (int i = 0; i < 4; i++) {
          if (bKMP(str[i], "xxxxxxx")) {
              flag[i] = true;
              flag1 = true;
          }
          if (flag1) {
              for (int i = 0; i < 4; i++) {
                  if (!flag[i] && bKMP(str[i], "xxxxxx")) {
                     // cout << "BLACK wins";
                      return BLACK;

                  }
              }
             // cout << "WHITE wins";
              return WHITE;


          }

      }//先判断有无长连禁手 如果有 再看其它方向上有无六连子 如果有 优先胜利
       //判断六连子
       for (int i = 0; i < 8; i++) {
           if (bKMP(str[i], "xxxxxx")) {
               //cout << "BLACK wins";
               return BLACK;
           }
           else if (bKMP(str[i], "oooooo")) {
               //cout << "WHITE wins";
               return WHITE;
           }
       }


       QString BanRoute4[3] = { "#xxxx#","#xx#xx#","#xxx#x#"};
       int weights4[3] = { 1,1,2};
       QString BanRoute5[5] = { "xxxx#x","xxx#xx","#xxxxx#","oxxxxx#","xxxxx#o"};
       int weights5[5] = { 2,2,1,2,2 };
       //判断四四禁手
       int tmp4=0;
       for (int i = 0; i < 8; i++) {
           for (int j = 0; j < 3; j++) {
               tmp4 += weights4[j] * iKMP(str[i], BanRoute4[j]);
           }

       }
       if (tmp4 >2) {
          // cout << "WHITE wins";
           return WHITE;
       }
       //判断五五禁手
       int tmp5=0;
       for (int i = 0; i < 8; i++) {
           for (int j = 0; j < 5; j++) {
               tmp4 += weights5[j] * iKMP(str[i], BanRoute5[j]);
           }

       }
       if (tmp5 > 2) {
           //cout << "WHITE wins";
           return WHITE;
       }
       return -1;

   }
