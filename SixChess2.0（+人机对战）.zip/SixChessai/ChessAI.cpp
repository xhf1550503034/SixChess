
#include "ChessAI.h"
#define NONE -1
#define BLACK 0
#define WHITE 1
ChessAI::ChessAI()
{
  initializeGameBoard(gameBoard);
}
void ChessAI::initializeScoreBoard(int score[23][23]){
    for(int i=0;i<23;i++){
        for(int j=0;j<23;j++){
            score[i][j]=0;
        }
    }
}
void ChessAI::initializeGameBoard(int game[23][23]){
    for(int i=0;i<23;i++){
        for(int j=0;j<23;j++){
            game[i][j]=NONE;
        }
    }
}
void ChessAI::calculateScore(){
    //统计人和ai连成的子
    int PersonNum=0;//玩家连成子的个数
    int aiNum=0;//ai连成子的个数
    int emptyNum=0;//各方向空白位的个数
    initializeScoreBoard(scoreBoard);

    //清空评分数组
    for (int row = 1; row <= 21; row++)
        for (int col = 0; col <=21; col++)
        {
            // 空白点就算
            if (gameBoard[row][col] == NONE)
            {
                // 遍历周围八个方向
                for (int y = -1; y <= 1; y++)
                    for (int x = -1; x <= 1; x++)
                    {
                        // 重置
                        PersonNum = 0;
                        aiNum = 0;
                        emptyNum = 0;

                        // 原坐标不算
                        if (!(y == 0 && x == 0))
                        {
                            // 每个方向延伸5个子

                            // 对玩家白子评分（正反两个方向）
                            for (int i = 1; i <= 5; i++)
                            {
                                if (row + i * y > 0 && row + i * y < 23 &&
                                    col + i * x > 0 && col + i * x < 23 &&
                                    gameBoard[row + i * y][col + i * x] == BLACK) // 真人玩家的子
                                {
                                    PersonNum++;
                                }
                                else if (row + i * y > 0 && row + i * y < 23 &&
                                         col + i * x > 0 && col + i * x < 23 &&
                                         gameBoard[row + i * y][col + i * x] == NONE) // 空白位
                                {
                                    emptyNum++;
                                    break;
                                }
                                else            // 出边界
                                    break;
                            }



                            if (PersonNum == 1)                      // 杀二
                                scoreBoard[row][col] += 10;
                            else if (PersonNum == 2)                 // 杀三
                            {
                                if (emptyNum == 1)
                                    scoreBoard[row][col] += 30;
                                else if (emptyNum == 2)

                                    scoreBoard[row][col] += 40;
                                else if (emptyNum == 3)
                                    scoreBoard[row][col] += 50;
                            }
                            else if (PersonNum == 3)                 // 杀四
                            {
                                // 量变空位不一样，优先级不一样
                                if (emptyNum == 1)
                                    scoreBoard[row][col] += 60;
                                else if (emptyNum == 2)
                                    scoreBoard[row][col] += 110;
                            }
                            else if (PersonNum == 4){
                                if (emptyNum == 1)
                                    scoreBoard[row][col] += 350;
                                else  scoreBoard[row][col] += 200;

                            }// 杀五
                            else if(PersonNum==5){
                                 scoreBoard[row][col] += 10000;
                            }


                            // 进行一次清空
                            emptyNum = 0;

                            // 对AI黑子评分
                            for (int i = 1; i <= 5; i++)
                            {
                                if (row + i * y > 0 && row + i * y < 23 &&
                                    col + i * x > 0 && col + i * x < 23 &&
                                    gameBoard[row + i * y][col + i * x] == WHITE) // 玩家的子
                                {
                                    aiNum++;
                                }
                                else if (row + i * y > 0 && row + i * y < 23 &&
                                         col + i * x > 0 && col + i * x < 23 &&
                                         gameBoard[row +i * y][col + i * x] == 0) // 空白位
                                {
                                    emptyNum++;
                                    break;
                                }
                                else            // 出边界
                                    break;
                            }



                            if (aiNum == 0)                      // 普通下子
                                scoreBoard[row][col] += 5;
                            else if (aiNum == 1)                 // 活二
                                scoreBoard[row][col] += 10;
                            else if (aiNum == 2)
                            {
                                if (emptyNum == 1)                // 死三
                                    scoreBoard[row][col] += 25;
                                else if (emptyNum == 2)
                                    scoreBoard[row][col] += 50;// 活三
                                else if(emptyNum == 3)
                                     scoreBoard[row][col] += 70;
                            }
                            else if (aiNum == 3)
                            {
                                if (emptyNum == 1)                // 死四
                                    scoreBoard[row][col] += 80;
                                else if (emptyNum == 2)
                                    scoreBoard[row][col] += 100; // 活四
                            }
                            else if (aiNum == 4){
                                if(emptyNum==1){
                                scoreBoard[row][col] += 200;
                                }// 活五
                                else  scoreBoard[row][col] += 150;
                           }
                            else if(aiNum==5){
                                scoreBoard[row][col] += 20000;
                            }

                        }
                    }

            }
        }
}
