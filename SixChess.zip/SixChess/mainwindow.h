#ifndef MAINWINDOW_H
#define MAINWINDOW_H
#include <QMainWindow>
#include"ChessBoard.h"
#include"ChessNode.h"
#include"Algorithm.h"
#include<QLabel>
class MainWindow : public QMainWindow
{
    Q_OBJECT

    int boardRow;
    int boardCol;
public:

    MainWindow(QWidget *parent = 0);
    ~MainWindow();
    //绘制棋盘
    void paintEvent(QPaintEvent *);
    void mouseMoveEvent(QMouseEvent *);

    void mouseReleaseEvent(QMouseEvent *);
    //void initialize();
     QLabel * lb_white_position;
      QLabel * lb_black_position;
    Algorithm algorithm;
    bool isblack=true;
    void mySlot1();


};


#endif // MAINWINDOW_H
