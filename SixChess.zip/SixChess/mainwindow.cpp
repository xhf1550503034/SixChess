#include "mainwindow.h"
#include"ChessBoard.h"
#include"ChessNode.h"
#include"Algorithm.h"
#include<QPainter>
#include<QPoint>
#include<QMouseEvent>
#include<QMessageBox>
#include<QPushButton>
#include<QObject>
#include<QString>
#include<QLabel>
#define BLACK 0
#define WHITE 1
const int BoardMargin = 40; // 棋盘边缘空隙
const int Noder = 15; // 棋子半径
const int Size=20;
const int BlockSize = 40; // 格子的大小

MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
{
    setMouseTracking(true); // 设置鼠标追踪
    isblack=true;
    // 设置棋盘大小
        setFixedSize(BoardMargin * 2 + BlockSize * Size+350, BoardMargin * 2 + BlockSize * Size);
        QPushButton *button=new QPushButton(this);
        button->setText("悔棋");
        button->setFixedWidth(100);
        button->setFixedHeight(70);
        button->move(950,750);
        connect(button,QPushButton::clicked,this,&MainWindow::mySlot1);
        QLabel * lb_white_position=new QLabel(this);
        QLabel * lb_black_position=new QLabel(this);
      QLabel *blackChess=new QLabel(this);
        blackChess->setText("黑棋坐标:");
      QLabel *whiteChess=new QLabel(this);
        whiteChess->setText("白棋坐标:");
      lb_white_position->move(950,300);
      lb_black_position->move(950,400);
       blackChess->move(950,250);
       whiteChess->move(950,350);
       lb_black_position->setText("2,3");
       lb_white_position->setText("1,8");
//       QString str="";
//       str+=QString::number(boardRow);
//       str+=",";
//       str+=QString::number(boardCol);
//       if(isblack){lb_black_position->setText(str); }
//       else {lb_white_position->setText(str);}
       update();

}
ChessBoard board(20);
void MainWindow::paintEvent(QPaintEvent *){
    QPainter painter(this);
      painter.setRenderHint(QPainter::Antialiasing, true); // 抗锯齿
      if(isblack)painter.setBrush(Qt::black);
        else painter.setBrush(Qt::white);
        //画鼠标光标
        if(boardRow>=0&&boardCol>=0){
      painter.drawEllipse(boardRow*BlockSize-6,boardCol*BlockSize-6,12,12);
        }
      //画21条横线
    for(int i=1;i<=21;i++){
        painter.drawLine(QPoint(i*BlockSize,BlockSize),QPoint(i*BlockSize,(Size+1)*BlockSize));

    }
    //画21条竖线
    for(int i=1;i<=21;i++){
        painter.drawLine(QPoint(BlockSize,i*BlockSize),QPoint((Size+1)*BlockSize,i*BlockSize));

    }
    for(int i=1;i<=21;i++){
        for(int j=1;j<=21;j++){
            if(board.showChessNode(i,j).getId()==BLACK){
                painter.setBrush(Qt::black);
                painter.drawEllipse(i*BlockSize-Noder,j*BlockSize-Noder,30,30);
            }
            else if(board.showChessNode(i,j).getId()==WHITE){
                painter.setBrush(Qt::white);
                painter.drawEllipse(i*BlockSize-Noder,j*BlockSize-Noder,30,30);
            }
        }
    }
}


void MainWindow::mySlot1(){
    board.ResetLCN();
    update();
    ChessNode tmp=board.showLatestNode();
    if(tmp.getId()==BLACK){
        isblack=false;
    }
    else{
        isblack=true;
    }//该方悔棋之后还由该方下
}

MainWindow::~MainWindow()
{

}

void MainWindow::mouseMoveEvent(QMouseEvent *ev){
    int mousex;
    mousex=ev->x();
    int mousey;
    mousey=ev->y();
    if(mousex>=25&&mousex<=855&&mousey>=25&&mousey<=855){
        setCursor(Qt::BlankCursor);
        boardRow=(mousex-Noder)/40+1;
        boardCol=(mousey-Noder)/40+1;//像素点转换成棋盘坐标
       if(board.showChessNode(boardRow,boardCol).getId()!=-1)
        setCursor(Qt::ForbiddenCursor);//展示图标坐标
       }
       else setCursor(Qt::ArrowCursor);
    update();
}

void MainWindow::mouseReleaseEvent(QMouseEvent *ev){
   int mousex;
   mousex=ev->x();
   int mousey;
   mousey=ev->y();
   if(mousex>=20&&mousey>=20&&mousey<=860&&mousey<=860){
      boardRow=(mousex-Noder)/40+1;
      boardCol=(mousey-Noder)/40+1;//像素点转换成棋盘坐标
     // qDebug()<<boardRow<<" "<<boardCol<<"   ";
      if(board.showChessNode(boardRow,boardCol).getId()==-1){
          int id;
          if(isblack){
               id=BLACK;
              isblack=!isblack;
            }
          else{
              id=WHITE;
              isblack=!isblack;
          }
          board.PlaceChessNode(boardRow,boardCol,id);//下棋
          if(algorithm.judge(board,Size)==BLACK){
              QMessageBox::warning(NULL,"提示","黑棋胜利");
              board.ResetBoard();
          }
          else if(algorithm.judge(board,Size)==WHITE){
              QMessageBox::warning(NULL,"提示","白棋胜利");
             board.ResetBoard();
          }

          update();
      }
   }
}



