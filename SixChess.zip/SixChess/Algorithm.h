#ifndef ALGORITHM_H
#define ALGORITHM_H
#include<QString>
#include"ChessBoard.h"
#include"ChessNode.h"

class Algorithm
{
public:
    Algorithm();
     bool bKMP(QString longstr, QString shortstr);
     //返回bool类型的KMP算法 即长字符串中是否含有短字符串
     int iKMP(QString longstr, QString shortstr);
     //返回int类型的KMP算法 即长字符串中有几个短字符串
     QString NodeTranslate(ChessNode c);
      QString strReverse(QString str);
      //字符串逆转
      QString * ScanNode(ChessBoard board, int size, ChessNode** node);
      int judge(ChessBoard board, int size);//判断胜负

};

#endif // ALGORITHM_H
